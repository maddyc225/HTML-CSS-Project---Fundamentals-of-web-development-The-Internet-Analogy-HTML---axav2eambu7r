# html-css-js-project-Photograhpy
Main page 
-company name
-view work button
-best picture
slides to show the work experience and tag lines
footer
-contact 
-email 